MATLAB

Run fs.m to generate the reference audio (reference.txt).

adc(selectedNoiseIndex) to create adc.txt.

rls(selectedNoiseIndex) to produce rlsOutput_raw.txt and rlsOutput.txt.

LabVIEW

Open the MFG_ENB_EE3001_Tx.gvi and MFG_ENB_EE3001_Rx.gvi projects.

Point each file‐path control to the corresponding .txt data files.


Prints

The final report figures under the Prints/ folder (e.g. tx_drill1.pdf, rx_drill2.pdf).


Captures

 CSV (Captures/csv/) for BER, error counts, graphs and spectrum data.